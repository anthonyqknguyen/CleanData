# VT-Beamer-Rmd
A Virginia Tech themed Beamer template for R Markdown
